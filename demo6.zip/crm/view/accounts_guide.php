<?php
include "../model/model.php";
/*======******Header******=======*/
require_once('layouts/admin_header.php');
?>
<?= begin_panel('iTours Accounts Introduction','') ?>

<div class="row">
<iframe width="100%" height="515" src="https://www.youtube.com/embed/p2RT9Vj41Tw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<?php
/*======******Footer******=======*/
require_once('layouts/admin_footer.php'); 
?>
